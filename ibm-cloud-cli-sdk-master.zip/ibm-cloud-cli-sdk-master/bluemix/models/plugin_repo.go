package models

type PluginRepo struct {
	Name string
	URL  string
}
