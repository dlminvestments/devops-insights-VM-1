package models

type Region struct {
	ID   string
	Name string
	Type string
}
