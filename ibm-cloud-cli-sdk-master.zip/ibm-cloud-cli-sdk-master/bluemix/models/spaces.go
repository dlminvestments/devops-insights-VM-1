package models

type SpaceFields struct {
	GUID     string
	Name     string
	AllowSSH bool
}
