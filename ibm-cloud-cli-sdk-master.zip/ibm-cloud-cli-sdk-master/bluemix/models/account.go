package models

type Account struct {
	GUID  string
	Name  string
	Owner string
}
