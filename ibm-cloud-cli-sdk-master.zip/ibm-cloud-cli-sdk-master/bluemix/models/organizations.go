package models

type OrganizationFields struct {
	GUID            string
	Name            string
	QuotaDefinition QuotaFields
}
